"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Camera, Check, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { SOSLogo } from "@/components/sos-logo"

export default function CreateOfficePage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    roomNumber: "",
    capacity: "",
    hasTable: "yes",
    isPrivate: "yes",
    hasPhone: "yes",
  })
  const [photoState, setPhotoState] = useState<"none" | "preview" | "approved">("none")
  const [photoPreview, setPhotoPreview] = useState<string>("")

  const handleTakePhoto = () => {
    setPhotoPreview("/modern-office-interior.png")
    setPhotoState("preview")
  }

  const handleApprove = () => {
    setPhotoState("approved")
  }

  const handleRetake = () => {
    setPhotoState("none")
    setPhotoPreview("")
  }

  const handleSubmit = () => {
    if (!formData.name.trim() || !formData.roomNumber.trim() || !formData.capacity) {
      alert("Please complete Office Name, Room #, and Capacity.")
      return
    }
    router.push("/oh-dashboard")
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-amber-50">
      <div
        style={{
          background: "linear-gradient(135deg, rgb(0, 51, 160) 0%, rgb(0, 76, 210) 100%)",
          boxShadow: "0 4px 20px rgba(0, 51, 160, 0.3)",
        }}
        className="text-white mb-8"
      >
        <div className="max-w-2xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white p-3 rounded-xl shadow-lg">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Create Office</h1>
                <p className="text-white/80 mt-1 text-lg">Add a new office to share</p>
              </div>
            </div>
            <Button
              asChild
              variant="outline"
              className="gap-2 bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 h-11 px-6"
            >
              <Link href="/oh-dashboard">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 pb-12 space-y-6">
        <Card className="p-8 space-y-6 border-2 shadow-lg bg-white" style={{ borderColor: "rgb(0, 51, 160)" }}>
          <div className="space-y-2">
            <Label htmlFor="name" style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
              Office Name
            </Label>
            <Input
              id="name"
              placeholder="Main Office"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="h-11 border-2"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="roomNumber" style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
              Room #
            </Label>
            <Input
              id="roomNumber"
              placeholder="214"
              value={formData.roomNumber}
              onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
              className="h-11 border-2"
            />
            <p className="text-xs text-gray-500">Building room number only</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="capacity" style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
              Capacity
            </Label>
            <Input
              id="capacity"
              type="number"
              placeholder="4"
              value={formData.capacity}
              onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
              className="h-11 border-2"
            />
            <p className="text-xs text-gray-500">Informational only - one booking at a time</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-3">
              <Label style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
                Table Available
              </Label>
              <RadioGroup
                value={formData.hasTable}
                onValueChange={(value) => setFormData({ ...formData, hasTable: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="table-yes" />
                    <Label htmlFor="table-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="table-no" />
                    <Label htmlFor="table-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
                Private
              </Label>
              <RadioGroup
                value={formData.isPrivate}
                onValueChange={(value) => setFormData({ ...formData, isPrivate: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="private-yes" />
                    <Label htmlFor="private-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="private-no" />
                    <Label htmlFor="private-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
                Phone Available
              </Label>
              <RadioGroup
                value={formData.hasPhone}
                onValueChange={(value) => setFormData({ ...formData, hasPhone: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="phone-yes" />
                    <Label htmlFor="phone-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="phone-no" />
                    <Label htmlFor="phone-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="space-y-3">
            <Label style={{ color: "rgb(0, 51, 160)" }} className="font-semibold">
              Office Photo
            </Label>
            {photoState === "none" && (
              <Button onClick={handleTakePhoto} variant="outline" className="w-full h-20 gap-2 bg-white border-2">
                <Camera className="w-6 h-6" />
                Take Photo
              </Button>
            )}
            {photoState === "preview" && (
              <div className="space-y-3">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden border-2">
                  <img
                    src={photoPreview || "/placeholder.svg"}
                    alt="Office preview"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleApprove}
                    className="flex-1 gap-2 shadow-sm"
                    style={{ background: "rgb(0, 51, 160)" }}
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                  <Button onClick={handleRetake} variant="outline" className="flex-1 bg-white border-2">
                    Retake
                  </Button>
                </div>
              </div>
            )}
            {photoState === "approved" && (
              <div className="space-y-3">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden border-2 border-green-600">
                  <img
                    src={photoPreview || "/placeholder.svg"}
                    alt="Office approved"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 bg-green-600 text-white p-1 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                </div>
                <Button onClick={handleRetake} variant="outline" size="sm" className="w-full bg-white border-2">
                  Change Photo
                </Button>
              </div>
            )}
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full h-12 font-bold text-base text-white shadow-lg"
            style={{ background: "rgb(0, 51, 160)" }}
          >
            Save Office
          </Button>
        </Card>
      </div>
    </main>
  )
}
