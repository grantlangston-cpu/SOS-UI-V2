"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Camera, Check, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { SOSLogo } from "@/components/sos-logo"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function EditOfficePage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "Main Office",
    roomNumber: "214",
    capacity: "4",
    hasTable: "yes",
    isPrivate: "yes",
    hasPhone: "yes",
  })
  const [photoState, setPhotoState] = useState<"none" | "preview" | "approved">("approved")
  const [photoPreview, setPhotoPreview] = useState<string>("/modern-office-interior.png")

  const handleTakePhoto = () => {
    setPhotoPreview("/modern-office-interior.png")
    setPhotoState("preview")
  }

  const handleApprove = () => {
    setPhotoState("approved")
  }

  const handleRetake = () => {
    setPhotoState("none")
    setPhotoPreview("")
  }

  const handleSubmit = () => {
    if (!formData.name.trim() || !formData.roomNumber.trim() || !formData.capacity) {
      alert("Please complete Office Name, Room #, and Capacity.")
      return
    }
    router.push("/oh-dashboard")
  }

  const handleDeleteOffice = () => {
    router.push("/oh-dashboard")
  }

  return (
    <main className="min-h-screen bg-muted/30">
      <div className="gradient-blue text-white shadow-blue mb-8">
        <div className="max-w-2xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white p-3 rounded-xl">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Edit Office</h1>
                <p className="text-white/80 mt-1 text-lg">Update office details</p>
              </div>
            </div>
            <Button
              asChild
              variant="outline"
              className="gap-2 bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 h-11 px-6"
            >
              <Link href="/oh-dashboard">Back</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 pb-12 space-y-6">
        <Card className="p-8 space-y-6 border-2 border-primary/20 shadow-blue bg-white">
          <div className="space-y-2">
            <Label htmlFor="name">Office Name</Label>
            <Input
              id="name"
              placeholder="Main Office"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="h-11"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="roomNumber">Room #</Label>
            <Input
              id="roomNumber"
              placeholder="214"
              value={formData.roomNumber}
              onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
              className="h-11"
            />
            <p className="text-xs text-gray-500">Building room number only</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="capacity">Capacity</Label>
            <Input
              id="capacity"
              type="number"
              placeholder="4"
              value={formData.capacity}
              onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
              className="h-11"
            />
            <p className="text-xs text-gray-500">Informational only - one booking at a time</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-3">
              <Label>Table Available</Label>
              <RadioGroup
                value={formData.hasTable}
                onValueChange={(value) => setFormData({ ...formData, hasTable: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="table-yes" />
                    <Label htmlFor="table-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="table-no" />
                    <Label htmlFor="table-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label>Private</Label>
              <RadioGroup
                value={formData.isPrivate}
                onValueChange={(value) => setFormData({ ...formData, isPrivate: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="private-yes" />
                    <Label htmlFor="private-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="private-no" />
                    <Label htmlFor="private-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label>Phone Available</Label>
              <RadioGroup
                value={formData.hasPhone}
                onValueChange={(value) => setFormData({ ...formData, hasPhone: value })}
              >
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="phone-yes" />
                    <Label htmlFor="phone-yes" className="cursor-pointer font-normal">
                      Yes
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="phone-no" />
                    <Label htmlFor="phone-no" className="cursor-pointer font-normal">
                      No
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="space-y-3">
            <Label>Office Photo</Label>
            {photoState === "none" && (
              <Button onClick={handleTakePhoto} variant="outline" className="w-full h-20 gap-2 bg-transparent">
                <Camera className="w-6 h-6" />
                Take Photo
              </Button>
            )}
            {photoState === "preview" && (
              <div className="space-y-3">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
                  <img
                    src={photoPreview || "/placeholder.svg"}
                    alt="Office preview"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleApprove} className="flex-1 gap-2">
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                  <Button onClick={handleRetake} variant="outline" className="flex-1 bg-transparent">
                    Retake
                  </Button>
                </div>
              </div>
            )}
            {photoState === "approved" && (
              <div className="space-y-3">
                <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden border-2 border-green-500">
                  <img
                    src={photoPreview || "/placeholder.svg"}
                    alt="Office approved"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 bg-green-500 text-white p-1 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                </div>
                <Button onClick={handleRetake} variant="outline" size="sm" className="w-full bg-transparent">
                  Change Photo
                </Button>
              </div>
            )}
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full h-12 font-bold text-base bg-primary hover:bg-primary/90 text-primary-foreground shadow-blue"
          >
            Save Changes
          </Button>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full h-12 font-bold text-base border-2 border-red-500 text-red-600 hover:bg-red-50 gap-2 bg-transparent"
              >
                <Trash2 className="w-4 h-4" />
                Delete this Office
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-white border-2 border-red-200">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-red-600">Delete Office</AlertDialogTitle>
                <AlertDialogDescription className="text-base">
                  Are you sure you want to delete "{formData.name}"? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="border-gray-300">Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteOffice} className="bg-red-600 hover:bg-red-700 text-white">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </Card>
      </div>
    </main>
  )
}
