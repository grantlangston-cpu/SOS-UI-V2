"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Phone } from "lucide-react"
import Link from "next/link"
import { SOSLogo } from "@/components/sos-logo"
import { Calendar } from "lucide-react"
import { handleText } from "@/lib/sms-utils"

const mockHistory = [
  {
    date: "2025-01-10",
    bookings: [
      {
        id: 1,
        time: "09:00 - 11:00",
        bookedBy: "Emily Davis",
        bookedByPhone: "(555) 123-9876",
      },
      {
        id: 2,
        time: "14:00 - 16:00",
        bookedBy: "James Wilson",
        bookedByPhone: "(555) 456-7890",
      },
    ],
  },
  {
    date: "2025-01-09",
    bookings: [
      {
        id: 3,
        time: "10:00 - 12:00",
        bookedBy: "Sarah Johnson",
        bookedByPhone: "(555) 234-5678",
      },
    ],
  },
  {
    date: "2025-01-08",
    bookings: [
      {
        id: 4,
        time: "13:00 - 15:00",
        bookedBy: "Michael Chen",
        bookedByPhone: "(555) 876-5432",
      },
      {
        id: 5,
        time: "15:30 - 17:00",
        bookedBy: "Lisa Brown",
        bookedByPhone: "(555) 345-6789",
      },
    ],
  },
  {
    date: "2025-01-05",
    bookings: [
      {
        id: 6,
        time: "11:00 - 13:00",
        bookedBy: "David Martinez",
        bookedByPhone: "(555) 567-8901",
      },
    ],
  },
]

export default function HistoryPage() {
  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split("-").map(Number)
    if (!y || !m || !d) return dateStr
    const date = new Date(y, m - 1, d)
    return date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })
  }

  return (
    <main className="min-h-screen bg-muted/30">
      <div className="gradient-blue text-white shadow-blue mb-8">
        <div className="max-w-4xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white p-3 rounded-xl">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Booking History</h1>
                <p className="text-white/80 mt-1 text-lg">Main Office - All-time records</p>
              </div>
            </div>
            <Button
              asChild
              variant="outline"
              className="gap-2 bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 h-11 px-6"
            >
              <Link href="/oh-dashboard">Back</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 pb-12 space-y-6">
        {mockHistory.map((day) => (
          <Card key={day.date} className="p-6 space-y-4 border-2 border-accent/30 shadow-gold bg-white">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Calendar className="w-6 h-6 text-accent" />
              {formatDate(day.date)}
            </h2>
            <div className="space-y-3">
              {day.bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-accent/5 rounded-lg border-2 border-accent/20"
                >
                  <div className="flex-1">
                    <div className="font-bold text-lg text-foreground">{booking.time}</div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <span className="font-medium">{booking.bookedBy}</span>
                      <Button
                        onClick={() => handleText(booking.bookedByPhone)}
                        variant="link"
                        className="h-auto p-0 text-primary hover:text-primary/80 gap-1 font-semibold"
                      >
                        <Phone className="w-4 h-4" />
                        TEXT
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </main>
  )
}
