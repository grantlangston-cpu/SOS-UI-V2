"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Building2, Calendar, History, Phone, Plus, LogOut, Clock } from "lucide-react"
import { SOSLogo } from "@/components/sos-logo"
import { handleText } from "@/lib/sms-utils"

// Mock data
const mockOffices = [
  {
    id: 1,
    name: "Main Office",
    roomNumber: "214",
    capacity: 4,
    hasTable: true,
    hasPhone: true,
    isPrivate: true,
    sharedSlots: [
      {
        id: 1,
        date: "2025-01-15",
        startTime: "09:00",
        endTime: "11:00",
        isBooked: true,
        bookedBy: "Sarah Johnson",
        bookedByPhone: "(555) 234-5678",
      },
      {
        id: 2,
        date: "2025-01-16",
        startTime: "14:00",
        endTime: "16:00",
        isBooked: false,
      },
      {
        id: 3,
        date: "2025-01-17",
        startTime: "10:00",
        endTime: "12:00",
        isBooked: true,
        bookedBy: "Michael Chen",
        bookedByPhone: "(555) 876-5432",
      },
    ],
  },
  {
    id: 2,
    name: "Corner Office",
    roomNumber: "305",
    capacity: 2,
    hasTable: false,
    hasPhone: true,
    isPrivate: false,
    sharedSlots: [
      {
        id: 4,
        date: "2025-01-15",
        startTime: "13:00",
        endTime: "15:00",
        isBooked: false,
      },
    ],
  },
]

export default function OHDashboard() {
  const router = useRouter()
  const [offices, setOffices] = useState(mockOffices)
  const [cancelDialog, setCancelDialog] = useState<{
    open: boolean
    officeId: number
    slotId: number
    isBooked: boolean
    bookedBy?: string
    bookedByPhone?: string
  } | null>(null)

  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split("-").map(Number)
    if (!y || !m || !d) return dateStr
    const date = new Date(y, m - 1, d)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
  }

  const handleCancelSlot = (
    officeId: number,
    slotId: number,
    isBooked: boolean,
    bookedBy?: string,
    bookedByPhone?: string,
  ) => {
    setCancelDialog({ open: true, officeId, slotId, isBooked, bookedBy, bookedByPhone })
  }

  const confirmCancel = () => {
    if (cancelDialog) {
      setOffices((prev) =>
        prev.map((office) => {
          if (office.id === cancelDialog.officeId) {
            return {
              ...office,
              sharedSlots: office.sharedSlots.filter((slot) => slot.id !== cancelDialog.slotId),
            }
          }
          return office
        }),
      )
      if (cancelDialog.isBooked && cancelDialog.bookedByPhone) {
        handleText(cancelDialog.bookedByPhone)
      }
      setCancelDialog(null)
    }
  }

  const handleLogout = () => {
    router.push("/")
  }

  return (
    <main className="min-h-screen" style={{ background: "linear-gradient(to bottom, #f0f4ff 0%, #fffbf0 100%)" }}>
      <div
        style={{
          background: "linear-gradient(135deg, rgb(0, 51, 160) 0%, rgb(0, 76, 210) 100%)",
          boxShadow: "0 4px 20px rgba(0, 51, 160, 0.3)",
        }}
      >
        <div className="max-w-6xl mx-auto p-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="bg-white p-4 rounded-2xl shadow-lg">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-5xl font-bold text-white">Office Holder Dashboard</h1>
                <p className="text-white/90 mt-2 text-lg font-medium">Manage your shared office spaces</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                asChild
                className="gap-2 font-bold h-12 px-8 text-base shadow-lg hover:scale-105 transition-transform"
                style={{
                  background: "rgb(255, 184, 28)",
                  color: "rgb(0, 51, 160)",
                  boxShadow: "0 4px 15px rgba(255, 184, 28, 0.4)",
                }}
              >
                <Link href="/oh-dashboard/create-office">
                  <Plus className="w-5 h-5" />
                  Add Office
                </Link>
              </Button>
              <Button
                onClick={handleLogout}
                className="gap-2 font-semibold h-12 px-6 shadow-md bg-white/20 backdrop-blur-sm text-white border-2 border-white/40 hover:bg-white/30"
              >
                <LogOut className="w-5 h-5" />
                Log Out
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-8 space-y-12">
        {/* Your Offices Section */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 rounded-xl" style={{ background: "rgb(0, 51, 160)" }}>
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: "rgb(0, 51, 160)" }}>
              Your Offices
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {offices.map((office) => (
              <Card
                key={office.id}
                className="p-8 space-y-6 bg-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]"
                style={{
                  border: "3px solid rgb(0, 51, 160)",
                  borderRadius: "20px",
                }}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-3xl font-bold" style={{ color: "rgb(0, 51, 160)" }}>
                        {office.name}
                      </h3>
                      <p className="text-lg font-semibold mt-1" style={{ color: "rgb(255, 184, 28)" }}>
                        Room #{office.roomNumber}
                      </p>
                    </div>
                    <div className="p-4 rounded-2xl" style={{ background: "rgba(0, 51, 160, 0.1)" }}>
                      <Building2 className="w-8 h-8" style={{ color: "rgb(0, 51, 160)" }} />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-4" style={{ borderTop: "2px solid rgba(0, 51, 160, 0.2)" }}>
                  <div className="flex-1">
                    <Button
                      asChild
                      className="w-full h-12 font-bold text-base transition-all hover:scale-105"
                      style={{
                        border: "2px solid rgb(0, 51, 160)",
                        color: "rgb(0, 51, 160)",
                        background: "white",
                      }}
                    >
                      <Link href={`/oh-dashboard/edit-office/${office.id}`}>Edit</Link>
                    </Button>
                  </div>
                  <div className="flex-1">
                    <Button
                      asChild
                      className="w-full gap-2 h-12 font-bold text-base shadow-lg hover:scale-105 transition-all"
                      style={{
                        background: "rgb(0, 51, 160)",
                        color: "white",
                        border: "2px solid rgb(0, 51, 160)",
                      }}
                    >
                      <Link href={`/oh-dashboard/share-space/${office.id}`}>
                        <Calendar className="w-5 h-5" />
                        Share
                      </Link>
                    </Button>
                  </div>
                  <div className="flex-1">
                    <Button
                      asChild
                      className="w-full gap-2 h-12 font-bold text-base transition-all hover:scale-105"
                      style={{
                        border: "2px solid rgb(255, 184, 28)",
                        color: "rgb(255, 184, 28)",
                        background: "white",
                      }}
                    >
                      <Link href={`/oh-dashboard/history/${office.id}`}>
                        <History className="w-5 h-5" />
                        History
                      </Link>
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ background: "rgb(255, 184, 28)" }}>
              <Clock className="w-8 h-8" style={{ color: "rgb(0, 51, 160)" }} />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: "rgb(0, 51, 160)" }}>
              Currently Shared (Next 7 Days)
            </h2>
          </div>

          <div className="space-y-6">
            {offices.map((office) => (
              <div key={office.id}>
                {office.sharedSlots.length > 0 && (
                  <Card
                    className="p-8 space-y-6 bg-white shadow-xl"
                    style={{
                      border: "3px solid rgb(255, 184, 28)",
                      borderRadius: "20px",
                    }}
                  >
                    <h3 className="text-2xl font-bold" style={{ color: "rgb(0, 51, 160)" }}>
                      {office.name} <span className="font-normal text-gray-600">(Room #{office.roomNumber})</span>
                    </h3>
                    <div className="space-y-4">
                      {office.sharedSlots.map((slot) => (
                        <div
                          key={slot.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl"
                          style={{
                            background: "linear-gradient(to right, rgba(255, 184, 28, 0.1), transparent)",
                            border: "2px solid rgba(255, 184, 28, 0.3)",
                          }}
                        >
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-4 flex-wrap">
                              <span className="font-bold text-xl" style={{ color: "rgb(0, 51, 160)" }}>
                                {formatDate(slot.date)}
                              </span>
                              <span className="text-gray-700 font-semibold text-lg">
                                {slot.startTime} - {slot.endTime}
                              </span>
                              {slot.isBooked && (
                                <Badge
                                  className="font-bold px-4 py-1.5 text-base"
                                  style={{
                                    background: "rgb(255, 184, 28)",
                                    color: "rgb(0, 51, 160)",
                                  }}
                                >
                                  Booked
                                </Badge>
                              )}
                            </div>
                            {slot.isBooked && (
                              <div className="flex items-center gap-4 text-base">
                                <span className="font-bold text-gray-900">{slot.bookedBy}</span>
                                <Button
                                  onClick={() => handleText(slot.bookedByPhone!)}
                                  className="h-auto p-0 font-bold gap-2 hover:underline"
                                  style={{
                                    color: "rgb(0, 51, 160)",
                                    background: "transparent",
                                  }}
                                  variant="link"
                                >
                                  <Phone className="w-5 h-5" />
                                  TEXT
                                </Button>
                              </div>
                            )}
                          </div>
                          <Button
                            onClick={() =>
                              handleCancelSlot(office.id, slot.id, slot.isBooked, slot.bookedBy, slot.bookedByPhone)
                            }
                            size="lg"
                            className="font-bold shadow-lg px-8 h-12 hover:scale-105 transition-transform"
                            style={{
                              background: "rgb(220, 38, 38)",
                              color: "white",
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      ))}
                    </div>
                  </Card>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={cancelDialog?.open || false} onOpenChange={(open) => !open && setCancelDialog(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Cancel Time Slot?</DialogTitle>
            <DialogDescription>
              {cancelDialog?.isBooked
                ? `This slot is booked by ${cancelDialog.bookedBy}. After you cancel, you'll be prompted to text them.`
                : "Are you sure you want to remove this availability slot?"}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setCancelDialog(null)} className="w-full sm:w-auto">
              Keep Slot
            </Button>
            <Button
              onClick={confirmCancel}
              className="w-full sm:w-auto bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              {cancelDialog?.isBooked ? "Cancel & Notify" : "Cancel Slot"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
