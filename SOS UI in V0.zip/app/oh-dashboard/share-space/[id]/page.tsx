"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Plus, Phone, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { SOSLogo } from "@/components/sos-logo"
import { handleText } from "@/lib/sms-utils"

const mockOffices = [
  { id: 1, name: "Main Office", roomNumber: "214" },
  { id: 2, name: "Corner Office", roomNumber: "305" },
]

const mockAvailability = [
  {
    id: 1,
    date: "2025-01-15",
    startTime: "09:00",
    endTime: "11:00",
    isBooked: true,
    bookedBy: "Sarah Johnson",
    bookedByPhone: "(555) 234-5678",
  },
  {
    id: 2,
    date: "2025-01-16",
    startTime: "14:00",
    endTime: "16:00",
    isBooked: false,
  },
  {
    id: 3,
    date: "2025-01-17",
    startTime: "10:00",
    endTime: "12:00",
    isBooked: true,
    bookedBy: "Michael Chen",
    bookedByPhone: "(555) 876-5432",
  },
  {
    id: 4,
    date: "2025-01-18",
    startTime: "13:00",
    endTime: "15:00",
    isBooked: false,
  },
]

export default function ShareSpacePage() {
  const [selectedOffice, setSelectedOffice] = useState("1")
  const [availabilityBlocks, setAvailabilityBlocks] = useState(mockAvailability)
  const [newBlock, setNewBlock] = useState({
    date: "",
    startTime: "",
    endTime: "",
  })
  const [removeDialog, setRemoveDialog] = useState<{
    open: boolean
    blockId: number
    isBooked: boolean
    bookedBy?: string
    bookedByPhone?: string
  } | null>(null)

  const todayISO = new Date().toISOString().slice(0, 10)
  const maxISO = (() => {
    const d = new Date()
    d.setDate(d.getDate() + 7)
    return d.toISOString().slice(0, 10)
  })()

  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split("-").map(Number)
    if (!y || !m || !d) return dateStr
    const date = new Date(y, m - 1, d)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
  }

  const handleAddBlock = () => {
    if (!newBlock.date || !newBlock.startTime || !newBlock.endTime) {
      alert("Please fill in all fields (date, start time, and end time)")
      return
    }

    const toMinutes = (t: string) => {
      const [h, m] = t.split(":").map(Number)
      return h * 60 + m
    }

    const start = toMinutes(newBlock.startTime)
    const end = toMinutes(newBlock.endTime)

    if (start >= end) {
      alert("End time must be after start time.")
      return
    }

    if (start % 15 !== 0 || end % 15 !== 0) {
      alert("Times must be in 15-minute increments.")
      return
    }

    if (end - start > 120) {
      alert("Maximum share window is 2 hours.")
      return
    }

    const overlaps = availabilityBlocks.some((b) => {
      if (b.date !== newBlock.date) return false
      const bs = toMinutes(b.startTime)
      const be = toMinutes(b.endTime)
      return start < be && end > bs
    })

    if (overlaps) {
      alert("That time overlaps an existing availability slot.")
      return
    }

    const newBlockWithId = {
      id: Date.now(),
      ...newBlock,
      isBooked: false,
    }

    setAvailabilityBlocks([...availabilityBlocks, newBlockWithId])
    setNewBlock({ date: "", startTime: "", endTime: "" })
  }

  const handleRemoveBlock = (id: number) => {
    const block = availabilityBlocks.find((b) => b.id === id)
    if (block) {
      setRemoveDialog({
        open: true,
        blockId: id,
        isBooked: block.isBooked,
        bookedBy: block.bookedBy,
        bookedByPhone: block.bookedByPhone,
      })
    }
  }

  const confirmRemove = () => {
    if (removeDialog) {
      setAvailabilityBlocks(availabilityBlocks.filter((block) => block.id !== removeDialog.blockId))
      setRemoveDialog(null)

      if (removeDialog.isBooked && removeDialog.bookedByPhone) {
        handleText(removeDialog.bookedByPhone)
      }
    }
  }

  const selectedOfficeName = mockOffices.find((o) => o.id.toString() === selectedOffice)?.name || "Main Office"

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-amber-50">
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div className="bg-gradient-to-r from-[#0033A0] to-[#0055CC] text-white rounded-lg shadow-lg p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <SOSLogo variant="icon" size="sm" />
              <div>
                <h1 className="text-3xl font-bold">Share Office Space</h1>
                <p className="text-blue-100 mt-1">Manage availability for your offices</p>
              </div>
            </div>
            <Button
              asChild
              variant="outline"
              className="gap-2 bg-white/10 border-white/30 hover:bg-white/20 text-white"
            >
              <Link href="/oh-dashboard">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Link>
            </Button>
          </div>
        </div>

        <Card className="p-6 space-y-4 border-2 border-[#0033A0] shadow-lg bg-white">
          <div className="space-y-2">
            <Label className="text-[#0033A0] font-semibold text-base">Select Office</Label>
            <Select value={selectedOffice} onValueChange={setSelectedOffice}>
              <SelectTrigger className="h-12 border-2 border-[#0033A0] bg-white text-[#0033A0] font-medium">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-white border-2 border-[#0033A0]">
                {mockOffices.map((office) => (
                  <SelectItem
                    key={office.id}
                    value={office.id.toString()}
                    className="bg-white hover:bg-blue-50 focus:bg-blue-50 text-[#0033A0] font-medium"
                  >
                    {office.name} (Room #{office.roomNumber})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </Card>

        <Card className="p-6 space-y-6 border-2 border-[#FFB81C] shadow-lg bg-white">
          <div className="border-l-4 border-[#FFB81C] pl-4">
            <h2 className="text-xl font-semibold text-[#0033A0]">Add Availability</h2>
            <p className="text-sm text-gray-600 mt-1">Create new time slots for this office</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date" className="text-[#0033A0] font-semibold">
                Date
              </Label>
              <Input
                id="date"
                type="date"
                min={todayISO}
                max={maxISO}
                value={newBlock.date}
                onChange={(e) => setNewBlock({ ...newBlock, date: e.target.value })}
                className="h-12 border-2 border-gray-300 focus:border-[#0033A0]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="startTime" className="text-[#0033A0] font-semibold">
                Start Time
              </Label>
              <Input
                id="startTime"
                type="time"
                value={newBlock.startTime}
                onChange={(e) => setNewBlock({ ...newBlock, startTime: e.target.value })}
                className="h-12 border-2 border-gray-300 focus:border-[#0033A0]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endTime" className="text-[#0033A0] font-semibold">
                End Time
              </Label>
              <Input
                id="endTime"
                type="time"
                value={newBlock.endTime}
                onChange={(e) => setNewBlock({ ...newBlock, endTime: e.target.value })}
                className="h-12 border-2 border-gray-300 focus:border-[#0033A0]"
              />
            </div>
          </div>
          <Button
            onClick={handleAddBlock}
            className="w-full sm:w-auto gap-2 bg-[#0033A0] hover:bg-[#0044BB] text-white font-semibold px-8 h-12 border-2 border-[#0033A0] shadow-md"
          >
            <Plus className="w-5 h-5" />
            Add Availability
          </Button>
        </Card>

        <Card className="p-6 space-y-6 border-2 border-[#0033A0] shadow-lg bg-white">
          <div className="bg-[#0033A0] text-white p-4 -m-6 mb-0 rounded-t-lg">
            <h2 className="text-xl font-semibold">Current Availability</h2>
            <p className="text-sm text-blue-100 mt-1">{selectedOfficeName} - Next 7 days</p>
          </div>
          <div className="space-y-3 pt-2">
            {availabilityBlocks.length === 0 ? (
              <div className="text-center py-12 text-gray-600">
                <p className="font-medium">No availability blocks yet.</p>
                <p className="text-sm mt-1">Add time slots above to share your office space.</p>
              </div>
            ) : (
              availabilityBlocks.map((block) => (
                <div
                  key={block.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-lg border-2 border-gray-200 bg-gradient-to-r from-blue-50 to-amber-50 shadow-sm"
                >
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-[#0033A0]">{formatDate(block.date)}</span>
                      <span className="text-gray-700 font-medium">
                        {block.startTime} - {block.endTime}
                      </span>
                      {block.isBooked && (
                        <Badge className="bg-[#FFB81C] text-[#0033A0] hover:bg-[#FFB81C]/90 font-semibold border border-[#0033A0]">
                          Booked
                        </Badge>
                      )}
                    </div>
                    {block.isBooked && (
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <span className="font-medium">{block.bookedBy}</span>
                        <Button
                          onClick={() => handleText(block.bookedByPhone!)}
                          variant="link"
                          className="h-auto p-0 text-[#0033A0] hover:text-[#0044BB] gap-1 font-bold"
                        >
                          <Phone className="w-3 h-3" />
                          TEXT
                        </Button>
                      </div>
                    )}
                  </div>
                  <Button
                    onClick={() => handleRemoveBlock(block.id)}
                    variant="outline"
                    size="sm"
                    className="text-red-600 border-2 border-red-600 hover:bg-red-50 font-semibold"
                  >
                    Remove
                  </Button>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      <Dialog open={removeDialog?.open || false} onOpenChange={(open) => !open && setRemoveDialog(null)}>
        <DialogContent className="sm:max-w-md bg-white border-2 border-[#0033A0]">
          <DialogHeader>
            <DialogTitle className="text-[#0033A0] text-xl font-bold">Remove Time Slot?</DialogTitle>
            <DialogDescription className="text-gray-700">
              {removeDialog?.isBooked
                ? `This slot is currently booked by ${removeDialog.bookedBy}. Confirming will open a text message to notify them of the cancellation.`
                : "Are you sure you want to remove this availability slot?"}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setRemoveDialog(null)}
              className="w-full sm:w-auto border-2 border-gray-300 font-semibold"
            >
              Keep Slot
            </Button>
            <Button
              onClick={confirmRemove}
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-semibold border-2 border-red-600"
            >
              {removeDialog?.isBooked ? "Remove & Notify" : "Remove Slot"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
