"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Check, X, Users, Calendar, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SOSLogo } from "@/components/sos-logo"

const mockOfficeData = {
  officeName: "Main Office",
  roomNumber: "214",
  capacity: 4,
  hasTable: true,
  hasPhone: true,
  isPrivate: true,
  photo: "/modern-office-interior.png",
  availableDate: "2025-01-17",
  availableStart: "10:00",
  availableEnd: "12:00",
}

export default function BookingPage() {
  const router = useRouter()
  const [selectedDate, setSelectedDate] = useState(mockOfficeData.availableDate)
  const [selectedStartTime, setSelectedStartTime] = useState(mockOfficeData.availableStart)
  const [selectedEndTime, setSelectedEndTime] = useState("")
  const [showConfirmation, setShowConfirmation] = useState(false)

  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split("-").map(Number)
    if (!y || !m || !d) return dateStr
    const date = new Date(y, m - 1, d)
    return date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })
  }

  const handleBook = () => {
    setShowConfirmation(true)
  }

  const addToGoogleCalendar = () => {
    const startDateTime = `${selectedDate}T${selectedStartTime}:00`
    const endDateTime = `${selectedDate}T${selectedEndTime}:00`
    const title = `Office Booking - ${mockOfficeData.officeName}`
    const location = `Room ${mockOfficeData.roomNumber}`

    const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${startDateTime.replace(/[-:]/g, "")}/${endDateTime.replace(/[-:]/g, "")}&location=${encodeURIComponent(location)}`
    window.open(googleCalendarUrl, "_blank")
  }

  const backToDashboard = () => {
    router.push("/ou-dashboard")
  }

  return (
    <main className="min-h-screen bg-muted/30">
      <div className="gradient-blue text-white shadow-blue mb-8">
        <div className="max-w-3xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white p-3 rounded-xl">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Book Office</h1>
                <p className="text-white/80 mt-1 text-lg">Select your time and confirm</p>
              </div>
            </div>
            <Button
              asChild
              variant="outline"
              className="gap-2 bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 h-11 px-6"
            >
              <Link href="/ou-dashboard">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 pb-12 space-y-8">
        <Card className="p-8 space-y-6 border-2 border-primary/20 shadow-blue bg-white">
          <div className="aspect-video bg-muted rounded-lg overflow-hidden border">
            <img
              src={mockOfficeData.photo || "/placeholder.svg"}
              alt={mockOfficeData.officeName}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-4">
            <div>
              <h2 className="text-2xl font-bold text-foreground">{mockOfficeData.officeName}</h2>
              <p className="text-muted-foreground">Room #{mockOfficeData.roomNumber}</p>
            </div>

            <div className="flex flex-wrap gap-4 text-sm py-4 border-t border-b">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Users className="w-4 h-4" />
                <span>Capacity: {mockOfficeData.capacity}</span>
              </div>
              <div className="flex items-center gap-2">
                {mockOfficeData.hasTable ? (
                  <>
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-muted-foreground">Table</span>
                  </>
                ) : (
                  <>
                    <X className="w-4 h-4 text-red-600" />
                    <span className="text-muted-foreground">No Table</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                {mockOfficeData.hasPhone ? (
                  <>
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-muted-foreground">Phone</span>
                  </>
                ) : (
                  <>
                    <X className="w-4 h-4 text-red-600" />
                    <span className="text-muted-foreground">No Phone</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                {mockOfficeData.isPrivate ? (
                  <>
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-muted-foreground">Private</span>
                  </>
                ) : (
                  <>
                    <X className="w-4 h-4 text-red-600" />
                    <span className="text-muted-foreground">Not Private</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Select Your Time</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Available slot: {mockOfficeData.availableStart} - {mockOfficeData.availableEnd} • Maximum: 2 hours •
                Increments: 15 minutes
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bookingDate" className="text-foreground font-medium">
                  Date
                </Label>
                <Input
                  id="bookingDate"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={mockOfficeData.availableDate}
                  max={mockOfficeData.availableDate}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="startTime" className="text-foreground font-medium">
                  Start Time
                </Label>
                <Input
                  id="startTime"
                  type="time"
                  value={selectedStartTime}
                  onChange={(e) => setSelectedStartTime(e.target.value)}
                  min={mockOfficeData.availableStart}
                  max={mockOfficeData.availableEnd}
                  step="900"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endTime" className="text-foreground font-medium">
                  End Time
                </Label>
                <Input
                  id="endTime"
                  type="time"
                  value={selectedEndTime}
                  onChange={(e) => setSelectedEndTime(e.target.value)}
                  min={selectedStartTime}
                  max={mockOfficeData.availableEnd}
                  step="900"
                  className="h-11"
                />
              </div>
            </div>
          </div>

          <Button
            onClick={handleBook}
            size="lg"
            className="w-full h-14 font-bold text-lg bg-primary hover:bg-primary/90 text-primary-foreground shadow-blue"
          >
            Confirm Booking
          </Button>
        </Card>
      </div>

      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="sm:max-w-md bg-white border-2 border-primary/20 shadow-blue">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-foreground flex items-center gap-3">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-7 h-7 text-white" />
              </div>
              Booking Confirmed
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="space-y-3">
              <p className="text-muted-foreground text-base">Your office has been successfully booked!</p>
              <div className="p-5 bg-primary/5 rounded-xl border-2 border-primary/20 space-y-1">
                <p className="font-bold text-foreground text-xl">{mockOfficeData.officeName}</p>
                <p className="text-sm text-muted-foreground font-medium">Room #{mockOfficeData.roomNumber}</p>
                <p className="text-sm text-muted-foreground font-bold mt-2">
                  {formatDate(selectedDate)} • {selectedStartTime} - {selectedEndTime}
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={addToGoogleCalendar}
                variant="outline"
                className="w-full gap-2 h-12 bg-transparent border-2 border-primary/30 hover:bg-primary/5 font-semibold"
              >
                <Calendar className="w-5 h-5" />
                Add to Google Calendar
              </Button>
              <Button
                onClick={backToDashboard}
                className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-bold shadow-blue"
              >
                Back to Dashboard
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  )
}
