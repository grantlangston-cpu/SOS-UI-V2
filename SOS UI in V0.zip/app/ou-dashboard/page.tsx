"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Check, X, Users, LogOut, Calendar, Building2 } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SOSLogo } from "@/components/sos-logo"

const mockBookedOffices = [
  {
    id: 1,
    officeName: "Main Office",
    roomNumber: "214",
    date: "2025-01-15",
    time: "09:00 - 11:00",
    capacity: 4,
    hasTable: true,
    hasPhone: true,
    isPrivate: true,
  },
  {
    id: 2,
    officeName: "Corner Office",
    roomNumber: "305",
    date: "2025-01-16",
    time: "14:00 - 16:00",
    capacity: 2,
    hasTable: false,
    hasPhone: true,
    isPrivate: false,
  },
]

const mockAvailableOffices = [
  {
    id: 3,
    officeName: "Main Office",
    roomNumber: "214",
    date: "2025-01-17",
    time: "10:00 - 12:00",
    capacity: 4,
    hasTable: true,
    hasPhone: true,
    isPrivate: true,
  },
  {
    id: 4,
    officeName: "Conference Room",
    roomNumber: "401",
    date: "2025-01-18",
    time: "13:00 - 15:00",
    capacity: 8,
    hasTable: true,
    hasPhone: true,
    isPrivate: true,
  },
  {
    id: 5,
    officeName: "Study Space",
    roomNumber: "102",
    date: "2025-01-19",
    time: "09:00 - 11:00",
    capacity: 3,
    hasTable: true,
    hasPhone: false,
    isPrivate: false,
  },
]

export default function OUDashboard() {
  const router = useRouter()
  const [bookedOffices, setBookedOffices] = useState(mockBookedOffices)
  const [cancelDialog, setCancelDialog] = useState<{
    open: boolean
    officeId: number
    officeName: string
  } | null>(null)

  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split("-").map(Number)
    if (!y || !m || !d) return dateStr
    const date = new Date(y, m - 1, d)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
  }

  const handleCancelBooking = (id: number, officeName: string) => {
    setCancelDialog({ open: true, officeId: id, officeName })
  }

  const confirmCancel = () => {
    if (cancelDialog) {
      setBookedOffices(bookedOffices.filter((office) => office.id !== cancelDialog.officeId))
      setCancelDialog(null)
    }
  }

  const handleLogout = () => {
    router.push("/")
  }

  const OfficeFeatures = ({
    capacity,
    hasTable,
    hasPhone,
    isPrivate,
  }: {
    capacity: number
    hasTable: boolean
    hasPhone: boolean
    isPrivate: boolean
  }) => (
    <div className="flex flex-wrap gap-3 text-sm">
      <div className="flex items-center gap-1 text-muted-foreground">
        <Users className="w-4 h-4" />
        <span>Capacity: {capacity}</span>
      </div>
      <div className="flex items-center gap-1">
        {hasTable ? (
          <>
            <Check className="w-4 h-4 text-green-600" />
            <span className="text-muted-foreground">Table</span>
          </>
        ) : (
          <>
            <X className="w-4 h-4 text-red-600" />
            <span className="text-muted-foreground">No Table</span>
          </>
        )}
      </div>
      <div className="flex items-center gap-1">
        {hasPhone ? (
          <>
            <Check className="w-4 h-4 text-green-600" />
            <span className="text-muted-foreground">Phone</span>
          </>
        ) : (
          <>
            <X className="w-4 h-4 text-red-600" />
            <span className="text-muted-foreground">No Phone</span>
          </>
        )}
      </div>
      <div className="flex items-center gap-1">
        {isPrivate ? (
          <>
            <Check className="w-4 h-4 text-green-600" />
            <span className="text-muted-foreground">Private</span>
          </>
        ) : (
          <>
            <X className="w-4 h-4 text-red-600" />
            <span className="text-muted-foreground">Not Private</span>
          </>
        )}
      </div>
    </div>
  )

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-amber-50">
      {/* Rich Header with Gradient */}
      <div className="gradient-blue text-white shadow-blue">
        <div className="max-w-6xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white p-3 rounded-xl">
                <SOSLogo variant="icon" size="sm" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Office User Dashboard</h1>
                <p className="text-white/80 mt-1 text-lg">Browse and book available office spaces</p>
              </div>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="gap-2 bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 h-11 px-6"
            >
              <LogOut className="w-5 h-5" />
              Log Out
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-8 space-y-12">
        {/* Currently Booked Section */}
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-[#0033A0] to-[#0044C0] text-white p-6 rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold flex items-center gap-3">
              <Calendar className="w-8 h-8" />
              Currently Booked
            </h2>
            <p className="text-white/90 mt-2 text-lg">Your confirmed bookings for the next 7 days</p>
          </div>
          {bookedOffices.length === 0 ? (
            <Card className="p-16 text-center border-4 border-dashed border-[#FFB81C] bg-amber-50">
              <div className="max-w-md mx-auto space-y-3">
                <Calendar className="w-16 h-16 text-[#FFB81C] mx-auto" />
                <p className="text-xl font-bold text-gray-800">You haven't booked any offices yet.</p>
                <p className="text-lg text-gray-600">Browse available spaces below to get started.</p>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {bookedOffices.map((office) => (
                <Card
                  key={office.id}
                  className="p-6 space-y-5 border-4 border-[#FFB81C] shadow-lg hover:shadow-2xl transition-all bg-gradient-to-br from-white to-amber-50"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">{office.officeName}</h3>
                      <p className="text-lg text-[#0033A0] font-bold">Room #{office.roomNumber}</p>
                    </div>
                    <Badge className="bg-[#FFB81C] text-gray-900 hover:bg-[#FFB81C] font-bold px-4 py-2 text-base border-2 border-amber-600">
                      Confirmed
                    </Badge>
                  </div>
                  <div className="space-y-3 bg-white/50 p-4 rounded-lg border-2 border-amber-200">
                    <div className="flex items-center gap-3 text-lg">
                      <span className="font-bold text-xl text-[#0033A0]">{formatDate(office.date)}</span>
                      <span className="text-gray-700 font-semibold">{office.time}</span>
                    </div>
                    <OfficeFeatures
                      capacity={office.capacity}
                      hasTable={office.hasTable}
                      hasPhone={office.hasPhone}
                      isPrivate={office.isPrivate}
                    />
                  </div>
                  <Button
                    onClick={() => handleCancelBooking(office.id, office.officeName)}
                    variant="outline"
                    size="lg"
                    className="w-full text-red-700 border-3 border-red-500 hover:bg-red-50 hover:border-red-600 font-bold text-base"
                  >
                    Cancel Booking
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Currently Available Section */}
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-[#0033A0] to-[#0044C0] text-white p-6 rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold flex items-center gap-3">
              <Building2 className="w-8 h-8" />
              Currently Available
            </h2>
            <p className="text-white/90 mt-2 text-lg">Open time slots for the next 7 days</p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockAvailableOffices.map((office) => (
              <Card
                key={office.id}
                className="p-6 space-y-5 border-4 border-[#0033A0] shadow-lg hover:shadow-2xl hover:border-[#0055E0] transition-all bg-gradient-to-br from-white to-blue-50"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-[#0033A0]">{office.officeName}</h3>
                    <p className="text-lg text-gray-700 font-bold">Room #{office.roomNumber}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className="border-3 border-[#0033A0] text-[#0033A0] bg-blue-50 font-bold px-4 py-2 text-base"
                  >
                    Available
                  </Badge>
                </div>
                <div className="space-y-3 bg-white/50 p-4 rounded-lg border-2 border-blue-200">
                  <div className="flex items-center gap-3 text-lg">
                    <span className="font-bold text-xl text-gray-900">{formatDate(office.date)}</span>
                    <span className="text-gray-700 font-semibold">{office.time}</span>
                  </div>
                  <OfficeFeatures
                    capacity={office.capacity}
                    hasTable={office.hasTable}
                    hasPhone={office.hasPhone}
                    isPrivate={office.isPrivate}
                  />
                </div>
                <Button
                  asChild
                  size="lg"
                  className="w-full bg-[#0033A0] hover:bg-[#0044C0] text-white font-bold shadow-lg text-base border-2 border-blue-900"
                >
                  <Link href={`/ou-dashboard/booking/${office.id}`}>Book Now</Link>
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={cancelDialog?.open || false} onOpenChange={(open) => !open && setCancelDialog(null)}>
        <DialogContent className="sm:max-w-md bg-white border-2 border-primary/20">
          <DialogHeader>
            <DialogTitle className="text-foreground">Cancel Booking?</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              <div className="space-y-2">
                <div>Are you sure you want to cancel your booking for {cancelDialog?.officeName}?</div>
                <div className="flex items-start gap-2 mt-3 p-3 bg-muted/50 rounded-lg border">
                  <Calendar className="w-4 h-4 mt-0.5 text-primary" />
                  <div className="text-sm">
                    Remember to remove this event from your Google Calendar manually if you've added it.
                  </div>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setCancelDialog(null)} className="w-full sm:w-auto">
              Keep Booking
            </Button>
            <Button
              onClick={confirmCancel}
              className="w-full sm:w-auto bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              Cancel Booking
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
