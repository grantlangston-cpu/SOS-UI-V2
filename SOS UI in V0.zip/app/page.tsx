"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { SOSLogo } from "@/components/sos-logo"
import { Calendar, Building2, Users } from "lucide-react"

export default function LandingPage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section with Gradient Background */}
      <div className="gradient-blue-gold min-h-screen flex items-center justify-center relative overflow-hidden">
        {/* Decorative Elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 w-full max-w-4xl mx-auto px-6 py-16 text-center space-y-12">
          {/* Logo and Title */}
          <div className="space-y-6">
            <div className="flex justify-center">
              <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-2xl">
                <SOSLogo variant="horizontal" size="lg" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white drop-shadow-lg leading-tight">
              Share Office Space
            </h1>
            <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto font-light">
              Campbell Hall's modern solution for efficient office scheduling and space sharing
            </p>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto pt-8">
            <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg">
              <Calendar className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold text-foreground mb-1">Easy Booking</h3>
              <p className="text-sm text-muted-foreground">Schedule office time in seconds</p>
            </div>
            <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg">
              <Building2 className="w-8 h-8 text-accent mx-auto mb-3" />
              <h3 className="font-semibold text-foreground mb-1">Multiple Spaces</h3>
              <p className="text-sm text-muted-foreground">Access various office locations</p>
            </div>
            <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg">
              <Users className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold text-foreground mb-1">Community First</h3>
              <p className="text-sm text-muted-foreground">Share resources efficiently</p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="space-y-4 max-w-md mx-auto pt-8">
            <Button
              asChild
              className="w-full h-14 text-lg font-semibold shadow-2xl bg-white text-primary hover:bg-white/90 border-2 border-white"
            >
              <Link href="/signup">Get Started</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="w-full h-14 text-lg font-semibold bg-white/10 backdrop-blur-sm text-white border-2 border-white/50 hover:bg-white/20"
            >
              <Link href="/login">Log In</Link>
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}
