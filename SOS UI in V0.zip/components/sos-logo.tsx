interface SOSLogoProps {
  variant?: "horizontal" | "icon" | "monochrome"
  size?: "sm" | "md" | "lg"
  className?: string
}

export function SOSLogo({ variant = "horizontal", size = "md", className = "" }: SOSLogoProps) {
  const sizes = {
    sm: { width: 120, height: 40, iconSize: 32 },
    md: { width: 180, height: 60, iconSize: 48 },
    lg: { width: 240, height: 80, iconSize: 64 },
  }

  const dimensions = sizes[size]

  if (variant === "icon") {
    return (
      <svg
        width={dimensions.iconSize}
        height={dimensions.iconSize}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        {/* Overlapping rooms icon */}
        <rect x="4" y="4" width="18" height="18" rx="2" fill="#0033A0" opacity="0.9" />
        <rect x="14" y="14" width="18" height="18" rx="2" fill="#FFB81C" opacity="0.9" />
        <rect x="26" y="26" width="18" height="18" rx="2" fill="#0033A0" opacity="0.9" />
      </svg>
    )
  }

  if (variant === "monochrome") {
    return (
      <svg
        width={dimensions.width}
        height={dimensions.height}
        viewBox="0 0 180 60"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        {/* Icon */}
        <rect x="2" y="16" width="12" height="12" rx="1.5" fill="currentColor" opacity="0.8" />
        <rect x="8" y="22" width="12" height="12" rx="1.5" fill="currentColor" opacity="0.6" />
        <rect x="14" y="28" width="12" height="12" rx="1.5" fill="currentColor" opacity="0.9" />

        {/* SOS Text */}
        <text
          x="38"
          y="36"
          fontFamily="Inter, system-ui, sans-serif"
          fontSize="28"
          fontWeight="700"
          fill="currentColor"
          letterSpacing="-0.5"
        >
          SOS
        </text>

        {/* Share Office Space */}
        <text
          x="38"
          y="50"
          fontFamily="Inter, system-ui, sans-serif"
          fontSize="9"
          fontWeight="500"
          fill="currentColor"
          opacity="0.7"
          letterSpacing="0.5"
        >
          SHARE OFFICE SPACE
        </text>
      </svg>
    )
  }

  return (
    <svg
      width={dimensions.width}
      height={dimensions.height}
      viewBox="0 0 180 60"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Icon - overlapping rooms */}
      <rect x="2" y="16" width="12" height="12" rx="1.5" fill="#0033A0" opacity="0.9" />
      <rect x="8" y="22" width="12" height="12" rx="1.5" fill="#FFB81C" opacity="0.9" />
      <rect x="14" y="28" width="12" height="12" rx="1.5" fill="#0033A0" opacity="0.9" />

      {/* SOS Text - Navy */}
      <text
        x="38"
        y="36"
        fontFamily="Inter, system-ui, sans-serif"
        fontSize="28"
        fontWeight="700"
        fill="#0033A0"
        letterSpacing="-0.5"
      >
        SOS
      </text>

      {/* Share Office Space - Gold accent */}
      <text
        x="38"
        y="50"
        fontFamily="Inter, system-ui, sans-serif"
        fontSize="9"
        fontWeight="500"
        fill="#FFB81C"
        letterSpacing="0.5"
      >
        SHARE OFFICE SPACE
      </text>
    </svg>
  )
}

export function SOSIcon({ size = 48, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <rect x="4" y="4" width="18" height="18" rx="2" fill="#0033A0" opacity="0.9" />
      <rect x="14" y="14" width="18" height="18" rx="2" fill="#FFB81C" opacity="0.9" />
      <rect x="26" y="26" width="18" height="18" rx="2" fill="#0033A0" opacity="0.9" />
    </svg>
  )
}
