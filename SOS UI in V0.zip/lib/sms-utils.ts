/**
 * Normalize phone number for SMS links
 * Strips all characters except digits and leading +
 */
export const normalizePhone = (phone: string): string => {
  return phone.replace(/[^\d+]/g, "")
}

/**
 * Handle SMS/text functionality
 * On mobile: Opens SMS app with the phone number
 * On desktop: Copies phone number to clipboard and shows toast
 */
export const handleText = async (phone: string, toastFn?: (message: string) => void) => {
  const normalized = normalizePhone(phone)

  // Check if device supports SMS (mobile)
  const isMobile = /iPhone|iPad|Android|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)

  if (isMobile) {
    // Open SMS app on mobile
    window.location.href = `sms:${normalized}`
  } else {
    // Copy to clipboard on desktop
    try {
      await navigator.clipboard.writeText(phone)
      if (toastFn) {
        toastFn("Phone number copied to clipboard")
      }
    } catch {
      // Fallback to alert if clipboard fails
      alert("Phone number copied to clipboard")
    }
  }
}
